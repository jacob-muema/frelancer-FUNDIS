<?php
session_start();

// Check if user is logged in and is a client
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fundihire";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$client_id = $_SESSION['user_id'];
$client_name = isset($_SESSION['name']) ? $_SESSION['name'] : "Client";
$job_message = "";
$profile_message = "";

// Handle job posting
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['post_job'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $budget = floatval($_POST['budget']);

    $stmt = $conn->prepare("INSERT INTO jobs (client_id, title, description, location, budget) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isssd", $client_id, $title, $description, $location, $budget);

    if ($stmt->execute()) {
        $job_message = "Job posted successfully!";
    } else {
        $job_message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $about = mysqli_real_escape_string($conn, $_POST['about']);

    // Update user profile
    $stmt = $conn->prepare("UPDATE users SET phone = ?, location = ?, bio = ? WHERE id = ?");
    $stmt->bind_param("sssi", $phone, $location, $about, $client_id);

    if ($stmt->execute()) {
        $profile_message = "Profile updated successfully!";
    } else {
        $profile_message = "Error updating profile: " . $stmt->error;
    }
    $stmt->close();
}

// Handle application approval
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['approve_application'])) {
    $application_id = intval($_POST['application_id']);
    $job_id = intval($_POST['job_id']);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update application status to accepted
        $stmt = $conn->prepare("UPDATE job_applications SET status = 'accepted' WHERE id = ?");
        $stmt->bind_param("i", $application_id);
        $stmt->execute();
        
        // Update job status to assigned
        $stmt = $conn->prepare("UPDATE jobs SET status = 'assigned' WHERE id = ?");
        $stmt->bind_param("i", $job_id);
        $stmt->execute();
        
        // Reject all other applications for this job
        $stmt = $conn->prepare("UPDATE job_applications SET status = 'rejected' WHERE job_id = ? AND id != ?");
        $stmt->bind_param("ii", $job_id, $application_id);
        $stmt->execute();
        
        $conn->commit();
        $job_message = "Application approved successfully! The fundi has been assigned to this job.";
    } catch (Exception $e) {
        $conn->rollback();
        $job_message = "Error: " . $e->getMessage();
    }
}

// Handle job completion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['complete_job'])) {
    $job_id = intval($_POST['job_id']);
    $rating = intval($_POST['rating']);
    $review = mysqli_real_escape_string($conn, $_POST['review']);
    
    // Update job status to completed
    $stmt = $conn->prepare("UPDATE jobs SET status = 'completed' WHERE id = ?");
    $stmt->bind_param("i", $job_id);
    
    if ($stmt->execute()) {
        // In a real application, you would save the rating and review to a reviews table
        $job_message = "Job marked as completed successfully!";
    } else {
        $job_message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch user profile data
$profile_query = "SELECT * FROM users WHERE id = $client_id";
$profile_result = $conn->query($profile_query);
$profile_data = $profile_result->fetch_assoc();

// Fetch jobs posted by the client
$jobs_query = "SELECT j.*, 
          (SELECT COUNT(*) FROM job_applications WHERE job_id = j.id) as applications_count 
          FROM jobs j 
          WHERE j.client_id = $client_id 
          ORDER BY j.created_at DESC";
$jobs_result = $conn->query($jobs_query);

// Fetch job applications for client's jobs
$applications_query = "SELECT ja.*, j.title as job_title, j.budget, j.location, j.status as job_status, 
                      u.name as fundi_name, u.id as fundi_id, u.phone as fundi_phone, u.email as fundi_email,
                      u.bio as fundi_bio, u.location as fundi_location
                      FROM job_applications ja 
                      JOIN jobs j ON ja.job_id = j.id 
                      JOIN users u ON ja.fundi_id = u.id 
                      WHERE j.client_id = $client_id 
                      ORDER BY ja.created_at DESC";
$applications_result = $conn->query($applications_query);

// Fetch active jobs (with accepted applications)
$active_jobs_query = "SELECT j.*, u.name as fundi_name, u.phone as fundi_phone, u.email as fundi_email,
                     ja.id as application_id 
                     FROM jobs j 
                     JOIN job_applications ja ON j.id = ja.job_id 
                     JOIN users u ON ja.fundi_id = u.id 
                     WHERE j.client_id = $client_id AND ja.status = 'accepted' AND j.status = 'assigned' 
                     ORDER BY j.updated_at DESC";
$active_jobs_result = $conn->query($active_jobs_query);

// Fetch completed jobs
$completed_jobs_query = "SELECT j.*, u.name as fundi_name, u.phone as fundi_phone, u.email as fundi_email
                        FROM jobs j 
                        JOIN job_applications ja ON j.id = ja.job_id 
                        JOIN users u ON ja.fundi_id = u.id 
                        WHERE j.client_id = $client_id AND j.status = 'completed' AND ja.status = 'accepted'
                        ORDER BY j.updated_at DESC";
$completed_jobs_result = $conn->query($completed_jobs_query);

// Count stats
$jobs_count = $jobs_result->num_rows;
$applications_count = $applications_result->num_rows;
$active_jobs_count = $active_jobs_result->num_rows;
$completed_jobs_count = $completed_jobs_result->num_rows;
$unread_messages = 0; // Placeholder for messages count

// Get pending applications count
$pending_applications_query = "SELECT COUNT(*) as count FROM job_applications ja 
                              JOIN jobs j ON ja.job_id = j.id 
                              WHERE j.client_id = $client_id AND ja.status = 'pending'";
$pending_result = $conn->query($pending_applications_query);
$pending_applications = $pending_result->fetch_assoc()['count'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard - FundiHire</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --secondary: #f59e0b;
            --secondary-dark: #d97706;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f1f5f9;
            --gray: #64748b;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --border-radius: 0.5rem;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }

        /* Line clamp utility */
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .line-clamp-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Layout */
        .dashboard {
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: var(--white);
            padding: 20px 0;
            position: fixed;
            width: 280px;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: var(--shadow);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo span {
            color: var(--secondary);
        }

        .user-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        .user-avatar {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background-color: var(--secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            font-size: 36px;
            color: var(--white);
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border: 3px solid rgba(255, 255, 255, 0.3);
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-name {
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 5px;
        }

        .user-role {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            background-color: rgba(255, 255, 255, 0.1);
            padding: 3px 10px;
            border-radius: 20px;
        }

        .sidebar-menu {
            padding: 20px;
        }

        .menu-title {
            text-transform: uppercase;
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
            margin: 20px 0 10px;
            letter-spacing: 1px;
        }

        .menu-items {
            list-style: none;
        }

        .menu-item {
            margin-bottom: 8px;
        }

        .menu-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: var(--border-radius);
            transition: var(--transition);
            cursor: pointer;
        }

        .menu-link:hover, .menu-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .menu-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .badge {
            background-color: var(--danger);
            color: var(--white);
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 11px;
            margin-left: auto;
            font-weight: 500;
        }

        /* Main Content */
        .main-content {
            grid-column: 2;
            padding: 25px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e2e8f0;
        }

        .page-title {
            font-size: 28px;
            color: var(--dark);
            font-weight: 700;
        }

        .header-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 18px;
            background-color: var(--primary);
            color: var(--white);
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .btn:active {
            transform: translateY(-1px);
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-primary {
            background-color: var(--primary);
        }

        .btn-secondary {
            background-color: var(--secondary);
            color: var(--white);
        }

        .btn-success {
            background-color: var(--success);
        }

        .btn-danger {
            background-color: var(--danger);
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }

        .btn-outline:hover {
            background-color: var(--primary);
            color: var(--white);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 14px;
        }

        /* Dashboard Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: var(--white);
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background-color: var(--primary);
        }

        .stat-card.blue::before {
            background-color: var(--info);
        }

        .stat-card.green::before {
            background-color: var(--success);
        }

        .stat-card.orange::before {
            background-color: var(--warning);
        }

        .stat-card.red::before {
            background-color: var(--danger);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .stat-icon.blue {
            background-color: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .stat-icon.green {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .stat-icon.orange {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .stat-icon.red {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .stat-info {
            flex: 1;
        }

        .stat-value {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            font-weight: 500;
        }

        /* Tabs */
        .tabs {
            margin-bottom: 25px;
        }

        .tab-nav {
            display: flex;
            background-color: var(--white);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .tab-link {
            flex: 1;
            padding: 15px;
            text-align: center;
            background-color: var(--white);
            color: var(--dark);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            border-bottom: 3px solid transparent;
            cursor: pointer;
        }

        .tab-link.active {
            border-bottom-color: var(--primary);
            color: var(--primary);
        }

        .tab-link:hover:not(.active) {
            background-color: var(--light);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Job Form */
        .job-form-container {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 30px;
        }

        .form-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--dark);
            display: flex;
            align-items: center;
            padding-bottom: 15px;
            border-bottom: 1px solid #e2e8f0;
        }

        .form-title i {
            margin-right: 10px;
            color: var(--primary);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: var(--border-radius);
            font-size: 15px;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .success-message {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            border-left: 4px solid var(--success);
        }

        .success-message i {
            margin-right: 10px;
            font-size: 18px;
        }

        /* Job Cards */
        .jobs-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 25px;
        }

        .job-card {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
            border: 1px solid #e2e8f0;
        }

        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .job-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #f8fafc;
        }

        .job-title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark);
        }

        .job-date {
            color: var(--gray);
            font-size: 13px;
            font-weight: 500;
        }

        .job-body {
            padding: 20px;
        }

        .job-description {
            color: #475569;
            margin-bottom: 20px;
            font-size: 15px;
        }

        .job-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }

        .job-meta-item {
            display: flex;
            align-items: center;
            font-size: 14px;
            color: var(--gray);
            background-color: #f1f5f9;
            padding: 6px 12px;
            border-radius: 20px;
        }

        .job-meta-item i {
            margin-right: 8px;
            font-size: 14px;
        }

        .job-budget {
            font-weight: bold;
            color: var(--success);
        }

        .job-footer {
            padding: 15px 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8fafc;
        }

        .job-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .status-open {
            background-color: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .status-assigned {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .status-completed {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .status-cancelled {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .applications-badge {
            background-color: var(--primary-light);
            color: var(--white);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-flex;
            align-items: center;
            margin-left: 10px;
            font-weight: 600;
        }

        .applications-badge i {
            margin-right: 5px;
            font-size: 10px;
        }

        /* Fundi Info */
        .fundi-info {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8fafc;
            border-radius: var(--border-radius);
        }

        .fundi-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: var(--dark);
            margin-right: 15px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .fundi-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .fundi-details {
            flex: 1;
        }

        .fundi-name {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .fundi-contact {
            font-size: 13px;
            color: var(--gray);
        }

        /* Profile Section */
        .profile-section {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 30px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: var(--light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: var(--dark);
            margin-right: 25px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border: 4px solid #e2e8f0;
        }

        .profile-info h2 {
            font-size: 28px;
            margin-bottom: 8px;
            color: var(--dark);
        }

        .profile-info p {
            color: var(--gray);
            font-size: 16px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 30px;
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        .empty-icon {
            font-size: 60px;
            color: #cbd5e1;
            margin-bottom: 25px;
        }

        .empty-title {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .empty-description {
            color: var(--gray);
            margin-bottom: 25px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            font-size: 16px;
            line-height: 1.6;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1100;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background-color: var(--white);
            z-index: 10;
        }

        .modal-title {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 22px;
            cursor: pointer;
            color: var(--gray);
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }

        .modal-close:hover {
            background-color: #f1f5f9;
            color: var(--danger);
        }

        .modal-body {
            padding: 20px;
        }

        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            position: sticky;
            bottom: 0;
            background-color: var(--white);
        }

        /* Application details */
        .application-details {
            margin-bottom: 20px;
        }

        .application-proposal {
            background-color: #f8fafc;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            border-left: 3px solid var(--primary);
        }

        .application-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .application-meta-item {
            font-size: 14px;
            color: var(--gray);
        }

        .application-meta-item strong {
            color: var(--dark);
            font-weight: 600;
        }

        /* Rating system */
        .rating-container {
            margin-bottom: 20px;
        }

        .rating {
            display: flex;
            gap: 5px;
            margin-top: 10px;
        }

        .rating-star {
            font-size: 24px;
            color: #cbd5e1;
            cursor: pointer;
            transition: var(--transition);
        }

        .rating-star:hover, .rating-star.active {
            color: var(--secondary);
        }

        /* Progress tracker */
        .progress-tracker {
            margin: 30px 0;
        }

        .progress-steps {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin-bottom: 30px;
        }

        .progress-steps::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: #e2e8f0;
            z-index: 1;
        }

        .progress-step {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
        }

        .step-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            color: var(--gray);
            font-size: 14px;
            font-weight: bold;
            position: relative;
        }

        .step-icon.active {
            background-color: var(--primary);
            color: var(--white);
        }

        .step-icon.completed {
            background-color: var(--success);
            color: var(--white);
        }

        .step-label {
            font-size: 13px;
            color: var(--gray);
            text-align: center;
            font-weight: 500;
        }

        .step-label.active {
            color: var(--primary);
            font-weight: 600;
        }

        .step-label.completed {
            color: var(--success);
            font-weight: 600;
        }

        /* Section visibility */
        .section {
            display: none;
        }

        .section.active {
            display: block;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .dashboard {
                grid-template-columns: 1fr;
            }

            .sidebar {
                display: none;
                width: 100%;
            }

            .sidebar.active {
                display: block;
            }

            .main-content {
                grid-column: 1;
            }

            .mobile-menu-toggle {
                display: block;
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1200;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background-color: var(--primary);
                color: var(--white);
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                border: none;
                cursor: pointer;
            }
        }

        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }

            .jobs-container {
                grid-template-columns: 1fr;
            }

            .form-row {
                flex-direction: column;
                gap: 0;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .header-actions {
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 576px) {
            .btn {
                padding: 8px 15px;
                font-size: 14px;
            }

            .tab-nav {
                flex-direction: column;
            }

            .profile-header {
                flex-direction: column;
                text-align: center;
            }

            .profile-avatar {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
<div class="dashboard">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo"><span>Fundi</span>Hire</div>
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-name"><?php echo $client_name; ?></div>
                <div class="user-role">Client</div>
            </div>
        </div>
        <div class="sidebar-menu">
            <div class="menu-title">Main Menu</div>
            <ul class="menu-items">
                <li class="menu-item">
                    <a class="menu-link active" data-section="dashboard-section">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="post-job-section">
                        <i class="fas fa-plus-circle"></i> Post a Job
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="my-jobs-section">
                        <i class="fas fa-briefcase"></i> My Jobs
                        <?php if ($jobs_count > 0): ?>
                            <span class="badge"><?php echo $jobs_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="active-jobs-section">
                        <i class="fas fa-tasks"></i> Active Jobs
                        <?php if ($active_jobs_count > 0): ?>
                            <span class="badge"><?php echo $active_jobs_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="applications-section">
                        <i class="fas fa-file-alt"></i> Applications
                        <?php if ($pending_applications > 0): ?>
                            <span class="badge"><?php echo $pending_applications; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
            <div class="menu-title">Account</div>
            <ul class="menu-items">
                <li class="menu-item">
                    <a class="menu-link" data-section="profile-section">
                        <i class="fas fa-user-circle"></i> My Profile
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="messages-section">
                        <i class="fas fa-envelope"></i> Messages
                        <?php if ($unread_messages > 0): ?>
                            <span class="badge"><?php echo $unread_messages; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="logout.php" class="menu-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Dashboard Section -->
        <section id="dashboard-section" class="section active">
            <div class="page-header">
                <h1 class="page-title">Welcome, <?php echo $client_name; ?>!</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="my-jobs-section">
                        <i class="fas fa-briefcase"></i> My Jobs
                    </button>
                    <button class="btn btn-primary" data-section="post-job-section">
                        <i class="fas fa-plus"></i> Post a Job
                    </button>
                </div>
            </div>

            <!-- Stats -->
            <div class="stats-container">
                <div class="stat-card blue">
                    <div class="stat-icon blue">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $jobs_count; ?></div>
                        <div class="stat-label">Posted Jobs</div>
                    </div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-icon orange">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $active_jobs_count; ?></div>
                        <div class="stat-label">Active Jobs</div>
                    </div>
                </div>
                <div class="stat-card green">
                    <div class="stat-icon green">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $completed_jobs_count; ?></div>
                        <div class="stat-label">Completed Jobs</div>
                    </div>
                </div>
                <div class="stat-card red">
                    <div class="stat-icon red">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $pending_applications; ?></div>
                        <div class="stat-label">Pending Applications</div>
                    </div>
                </div>
            </div>

            <!-- Quick Post Job Form -->
            <div class="job-form-container">
                <h2 class="form-title"><i class="fas fa-plus-circle"></i> Post a New Job</h2>
                
                <?php if (!empty($job_message)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $job_message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <input type="hidden" name="post_job" value="1">
                    <div class="form-group">
                        <label for="title" class="form-label">Job Title</label>
                        <input type="text" id="title" name="title" class="form-control" placeholder="e.g. Need a Plumber for Bathroom Renovation" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description" class="form-label">Job Description</label>
                        <textarea id="description" name="description" class="form-control" placeholder="Describe the job in detail..." required></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" id="location" name="location" class="form-control" placeholder="e.g. Nairobi, Westlands" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="budget" class="form-label">Budget (KES)</label>
                            <input type="number" id="budget" name="budget" class="form-control" placeholder="Enter your budget" min="0" step="0.01" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Post Job
                    </button>
                </form>
            </div>

            <!-- Tabs -->
            <div class="tabs">
                <div class="tab-nav">
                    <div class="tab-link active" data-tab="posted-jobs">Posted Jobs</div>
                    <div class="tab-link" data-tab="active-jobs">Active Jobs</div>
                    <div class="tab-link" data-tab="applications">Applications</div>
                </div>
            </div>

            <!-- Posted Jobs Tab -->
            <div id="posted-jobs" class="tab-content active">
                <?php if ($jobs_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($jobs_result, 0);
                        while ($job = $jobs_result->fetch_assoc()): 
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                                    <div class="job-date"><?php echo date('M d, Y', strtotime($job['created_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <p class="job-description line-clamp-3"><?php echo htmlspecialchars($job['description']); ?></p>
                                    <div class="job-meta">
                                        <div class="job-meta-item">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($job['location']); ?>
                                        </div>
                                        <div class="job-meta-item job-budget">
                                            <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($job['budget'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <div>
                                        <span class="job-status status-<?php echo $job['status']; ?>"><?php echo ucfirst($job['status']); ?></span>
                                        <?php if ($job['applications_count'] > 0): ?>
                                            <span class="applications-badge">
                                                <i class="fas fa-user"></i> <?php echo $job['applications_count']; ?> applications
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <button class="btn btn-outline btn-sm view-job" data-id="<?php echo $job['id']; ?>">View Details</button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-briefcase"></i></div>
                        <h3 class="empty-title">No Jobs Posted Yet</h3>
                        <p class="empty-description">You haven't posted any jobs yet. Use the form above to post your first job and find skilled fundis.</p>
                        <button class="btn btn-primary" data-section="post-job-section">Post Your First Job</button>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Active Jobs Tab -->
            <div id="active-jobs" class="tab-content">
                <?php if ($active_jobs_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($active_jobs_result, 0);
                        while ($active_job = $active_jobs_result->fetch_assoc()): 
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($active_job['title']); ?></h3>
                                    <div class="job-date">Started: <?php echo date('M d, Y', strtotime($active_job['updated_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <div class="fundi-info">
                                        <div class="fundi-avatar">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="fundi-details">
                                            <div class="fundi-name"><?php echo $active_job['fundi_name']; ?></div>
                                            <div class="fundi-contact">
                                                <i class="fas fa-phone"></i> <?php echo $active_job['fundi_phone']; ?> | 
                                                <i class="fas fa-envelope"></i> <?php echo $active_job['fundi_email']; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="job-meta">
                                        <div class="job-meta-item">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($active_job['location']); ?>
                                        </div>
                                        <div class="job-meta-item job-budget">
                                            <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($active_job['budget'], 2); ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Progress tracker -->
                                    <div class="progress-tracker">
                                        <div class="progress-steps">
                                            <div class="progress-step">
                                                <div class="step-icon completed">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                                <div class="step-label completed">Assigned</div>
                                            </div>
                                            <div class="progress-step">
                                                <div class="step-icon active">
                                                    <i class="fas fa-tools"></i>
                                                </div>
                                                <div class="step-label active">In Progress</div>
                                            </div>
                                            <div class="progress-step">
                                                <div class="step-icon">
                                                    <i class="fas fa-check-circle"></i>
                                                </div>
                                                <div class="step-label">Completed</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <span class="job-status status-assigned">In Progress</span>
                                    <div>
                                        <button class="btn btn-outline btn-sm message-fundi" data-id="<?php echo $active_job['fundi_id']; ?>">
                                            <i class="fas fa-comment"></i> Message
                                        </button>
                                        <button class="btn btn-primary btn-sm complete-job" data-id="<?php echo $active_job['id']; ?>">
                                            <i class="fas fa-check-circle"></i> Mark Complete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-tasks"></i></div>
                        <h3 class="empty-title">No Active Jobs</h3>
                        <p class="empty-description">You don't have any active jobs at the moment. Once you accept a fundi's application, the job will appear here.</p>
                        <button class="btn btn-primary" data-section="applications-section">View Applications</button>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Applications Tab -->
            <div id="applications" class="tab-content">
                <?php if ($applications_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($applications_result, 0);
                        while ($application = $applications_result->fetch_assoc()): 
                            if ($application['status'] == 'pending'):
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($application['job_title']); ?></h3>
                                    <div class="job-date">Applied: <?php echo date('M d, Y', strtotime($application['created_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <div class="fundi-info">
                                        <div class="fundi-avatar">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="fundi-details">
                                            <div class="fundi-name"><?php echo $application['fundi_name']; ?></div>
                                            <div class="fundi-contact">
                                                <i class="fas fa-map-marker-alt"></i> <?php echo $application['fundi_location']; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="application-proposal">
                                        <p><?php echo nl2br(htmlspecialchars($application['proposal'])); ?></p>
                                    </div>
                                    <div class="application-meta">
                                        <div class="application-meta-item">
                                            <strong>Job Budget:</strong> KES <?php echo number_format($application['budget'], 2); ?>
                                        </div>
                                        <div class="application-meta-item">
                                            <strong>Bid Amount:</strong> KES <?php echo number_format($application['bid_amount'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <span class="job-status status-open">Pending</span>
                                    <div>
                                        <button class="btn btn-outline btn-sm view-fundi-profile" data-id="<?php echo $application['fundi_id']; ?>">
                                            <i class="fas fa-user"></i> View Profile
                                        </button>
                                        <button class="btn btn-primary btn-sm approve-application" 
                                                data-application-id="<?php echo $application['id']; ?>" 
                                                data-job-id="<?php echo $application['job_id']; ?>"
                                                data-fundi-name="<?php echo $application['fundi_name']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php 
                            endif;
                        endwhile; 
                        ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-file-alt"></i></div>
                        <h3 class="empty-title">No Applications Yet</h3>
                        <p class="empty-description">You don't have any applications for your jobs yet. Check back later or post more jobs to attract fundis.</p>
                        <button class="btn btn-primary" data-section="post-job-section">Post a New Job</button>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- Post Job Section -->
        <section id="post-job-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Post a New Job</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <div class="job-form-container">
                <?php if (!empty($job_message)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $job_message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <input type="hidden" name="post_job" value="1">
                    <div class="form-group">
                        <label for="title2" class="form-label">Job Title</label>
                        <input type="text" id="title2" name="title" class="form-control" placeholder="e.g. Need a Plumber for Bathroom Renovation" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description2" class="form-label">Job Description</label>
                        <textarea id="description2" name="description" class="form-control" placeholder="Describe the job in detail..." required></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="location2" class="form-label">Location</label>
                            <input type="text" id="location2" name="location" class="form-control" placeholder="e.g. Nairobi, Westlands" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="budget2" class="form-label">Budget (KES)</label>
                            <input type="number" id="budget2" name="budget" class="form-control" placeholder="Enter your budget" min="0" step="0.01" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Post Job
                    </button>
                </form>
            </div>
        </section>

        <!-- My Jobs Section -->
        <section id="my-jobs-section" class="section">
            <div class="page-header">
                <h1 class="page-title">My Jobs</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                    <button class="btn btn-primary" data-section="post-job-section">
                        <i class="fas fa-plus"></i> Post a Job
                    </button>
                </div>
            </div>

            <?php if ($jobs_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($jobs_result, 0);
                    while ($job = $jobs_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                                <div class="job-date"><?php echo date('M d, Y', strtotime($job['created_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <p class="job-description line-clamp-3"><?php echo htmlspecialchars($job['description']); ?></p>
                                <div class="job-meta">
                                    <div class="job-meta-item">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($job['location']); ?>
                                    </div>
                                    <div class="job-meta-item job-budget">
                                        <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($job['budget'], 2); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="job-footer">
                                <div>
                                    <span class="job-status status-<?php echo $job['status']; ?>"><?php echo ucfirst($job['status']); ?></span>
                                    <?php if ($job['applications_count'] > 0): ?>
                                        <span class="applications-badge">
                                            <i class="fas fa-user"></i> <?php echo $job['applications_count']; ?> applications
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <button class="btn btn-outline btn-sm view-job" data-id="<?php echo $job['id']; ?>">View Details</button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-briefcase"></i></div>
                    <h3 class="empty-title">No Jobs Posted Yet</h3>
                    <p class="empty-description">You haven't posted any jobs yet. Use the form above to post your first job and find skilled fundis.</p>
                    <button class="btn btn-primary" data-section="post-job-section">Post Your First Job</button>
                </div>
            <?php endif; ?>
        </section>

        <!-- Active Jobs Section -->
        <section id="active-jobs-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Active Jobs</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <?php if ($active_jobs_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($active_jobs_result, 0);
                    while ($active_job = $active_jobs_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($active_job['title']); ?></h3>
                                <div class="job-date">Started: <?php echo date('M d, Y', strtotime($active_job['updated_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <div class="fundi-info">
                                    <div class="fundi-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="fundi-details">
                                        <div class="fundi-name"><?php echo $active_job['fundi_name']; ?></div>
                                        <div class="fundi-contact">
                                            <i class="fas fa-phone"></i> <?php echo $active_job['fundi_phone']; ?> | 
                                            <i class="fas fa-envelope"></i> <?php echo $active_job['fundi_email']; ?>
                                        </div>
                                    </div>
                                </div>
                                <p class="job-description line-clamp-2"><?php echo htmlspecialchars($active_job['description']); ?></p>
                                <div class="job-meta">
                                    <div class="job-meta-item">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($active_job['location']); ?>
                                    </div>
                                    <div class="job-meta-item job-budget">
                                        <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($active_job['budget'], 2); ?>
                                    </div>
                                </div>
                                
                                <!-- Progress tracker -->
                                <div class="progress-tracker">
                                    <div class="progress-steps">
                                        <div class="progress-step">
                                            <div class="step-icon completed">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="step-label completed">Assigned</div>
                                        </div>
                                        <div class="progress-step">
                                            <div class="step-icon active">
                                                <i class="fas fa-tools"></i>
                                            </div>
                                            <div class="step-label active">In Progress</div>
                                        </div>
                                        <div class="progress-step">
                                            <div class="step-icon">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <div class="step-label">Completed</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="job-footer">
                                <span class="job-status status-assigned">In Progress</span>
                                <div>
                                    <button class="btn btn-outline btn-sm message-fundi" data-id="<?php echo $active_job['fundi_id']; ?>">
                                        <i class="fas fa-comment"></i> Message
                                    </button>
                                    <button class="btn btn-primary btn-sm complete-job" data-id="<?php echo $active_job['id']; ?>">
                                        <i class="fas fa-check-circle"></i> Mark Complete
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-tasks"></i></div>
                    <h3 class="empty-title">No Active Jobs</h3>
                    <p class="empty-description">You don't have any active jobs at the moment. Once you accept a fundi's application, the job will appear here.</p>
                    <button class="btn btn-primary" data-section="applications-section">View Applications</button>
                </div>
            <?php endif; ?>
        </section>

        <!-- Applications Section -->
        <section id="applications-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Job Applications</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <?php if ($applications_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($applications_result, 0);
                    while ($application = $applications_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($application['job_title']); ?></h3>
                                <div class="job-date">Applied: <?php echo date('M d, Y', strtotime($application['created_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <div class="fundi-info">
                                    <div class="fundi-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="fundi-details">
                                        <div class="fundi-name"><?php echo $application['fundi_name']; ?></div>
                                        <div class="fundi-contact">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo $application['fundi_location']; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="application-proposal">
                                    <p><?php echo nl2br(htmlspecialchars($application['proposal'])); ?></p>
                                </div>
                                <div class="application-meta">
                                    <div class="application-meta-item">
                                        <strong>Job Budget:</strong> KES <?php echo number_format($application['budget'], 2); ?>
                                    </div>
                                    <div class="application-meta-item">
                                        <strong>Bid Amount:</strong> KES <?php echo number_format($application['bid_amount'], 2); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="job-footer">
                                <?php if ($application['status'] == 'pending'): ?>
                                    <span class="job-status status-open">Pending</span>
                                    <div>
                                        <button class="btn btn-outline btn-sm view-fundi-profile" data-id="<?php echo $application['fundi_id']; ?>">
                                            <i class="fas fa-user"></i> View Profile
                                        </button>
                                        <button class="btn btn-primary btn-sm approve-application" 
                                                data-application-id="<?php echo $application['id']; ?>" 
                                                data-job-id="<?php echo $application['job_id']; ?>"
                                                data-fundi-name="<?php echo $application['fundi_name']; ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    </div>
                                <?php elseif ($application['status'] == 'accepted'): ?>
                                    <span class="job-status status-assigned">Accepted</span>
                                    <button class="btn btn-outline btn-sm view-fundi-profile" data-id="<?php echo $application['fundi_id']; ?>">
                                        <i class="fas fa-user"></i> View Profile
                                    </button>
                                <?php else: ?>
                                    <span class="job-status status-cancelled">Rejected</span>
                                    <button class="btn btn-outline btn-sm view-fundi-profile" data-id="<?php echo $application['fundi_id']; ?>">
                                        <i class="fas fa-user"></i> View Profile
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-file-alt"></i></div>
                    <h3 class="empty-title">No Applications Yet</h3>
                    <p class="empty-description">You don't have any applications for your jobs yet. Check back later or post more jobs to attract fundis.</p>
                    <button class="btn btn-primary" data-section="post-job-section">Post a New Job</button>
                </div>
            <?php endif; ?>
        </section>

        <!-- Profile Section -->
        <section id="profile-section" class="section">
            <div class="page-header">
                <h1 class="page-title">My Profile</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <div class="profile-section">
                <?php if (!empty($profile_message)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $profile_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="profile-info">
                        <h2><?php echo $client_name; ?></h2>
                        <p><i class="fas fa-user-tag"></i> Client</p>
                        <?php if (!empty($profile_data['email'])): ?>
                            <p><i class="fas fa-envelope"></i> <?php echo $profile_data['email']; ?></p>
                        <?php endif; ?>
                        <?php if (!empty($profile_data['phone'])): ?>
                            <p><i class="fas fa-phone"></i> <?php echo $profile_data['phone']; ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="profile-form">
                    <form action="" method="post">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" value="<?php echo $client_name; ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?php echo isset($profile_data['email']) ? $profile_data['email'] : ''; ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="phone" class="form-control" placeholder="Enter your phone number" value="<?php echo isset($profile_data['phone']) ? $profile_data['phone'] : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Location</label>
                            <input type="text" name="location" class="form-control" placeholder="Enter your location" value="<?php echo isset($profile_data['location']) ? $profile_data['location'] : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">About</label>
                            <textarea name="about" class="form-control" placeholder="Tell us about yourself..."><?php echo isset($profile_data['bio']) ? $profile_data['bio'] : ''; ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Profile
                        </button>
                    </form>
                </div>
            </div>
        </section>

        <!-- Messages Section -->
        <section id="messages-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Messages</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-envelope"></i></div>
                <h3 class="empty-title">No Messages Yet</h3>
                <p class="empty-description">You don't have any messages yet. Once you start communicating with fundis, your messages will appear here.</p>
                <button class="btn btn-primary" data-section="active-jobs-section">View Active Jobs</button>
            </div>
        </section>
    </main>
</div>

<!-- Approve Application Modal -->
<div id="approve-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Approve Application</h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to approve <span id="fundi-name-placeholder"></span> for this job?</p>
            <p>This will assign the job to this fundi and reject all other applications.</p>
            
            <form id="approve-form" method="post">
                <input type="hidden" name="approve_application" value="1">
                <input type="hidden" name="application_id" id="application_id">
                <input type="hidden" name="job_id" id="job_id">
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline modal-close-btn">Cancel</button>
            <button class="btn btn-primary" id="confirm-approve">Approve</button>
        </div>
    </div>
</div>

<!-- Complete Job Modal -->
<div id="complete-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Complete Job</h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you satisfied with the work done? Please rate the fundi and provide feedback.</p>
            
            <form id="complete-form" method="post">
                <input type="hidden" name="complete_job" value="1">
                <input type="hidden" name="job_id" id="complete_job_id">
                
                <div class="form-group">
                    <label class="form-label">Rate the Fundi</label>
                    <div class="rating">
                        <span class="rating-star" data-rating="1"><i class="fas fa-star"></i></span>
                        <span class="rating-star" data-rating="2"><i class="fas fa-star"></i></span>
                        <span class="rating-star" data-rating="3"><i class="fas fa-star"></i></span>
                        <span class="rating-star" data-rating="4"><i class="fas fa-star"></i></span>
                        <span class="rating-star" data-rating="5"><i class="fas fa-star"></i></span>
                    </div>
                    <input type="hidden" name="rating" id="rating_value" value="5">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Review (Optional)</label>
                    <textarea name="review" class="form-control" placeholder="Share your experience with this fundi..."></textarea>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline modal-close-btn">Cancel</button>
            <button class="btn btn-primary" id="confirm-complete">Complete Job</button>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Section navigation
        const menuLinks = document.querySelectorAll('.menu-link[data-section], .btn[data-section]');
        const sections = document.querySelectorAll('.section');

        menuLinks.forEach(link => {
            link.addEventListener('click', function() {
                const sectionId = this.getAttribute('data-section');
                
                // Hide all sections
                sections.forEach(section => {
                    section.classList.remove('active');
                });
                
                // Show selected section
                document.getElementById(sectionId).classList.add('active');
                
                // Update active menu link
                document.querySelectorAll('.menu-link').forEach(menuLink => {
                    menuLink.classList.remove('active');
                    if (menuLink.getAttribute('data-section') === sectionId) {
                        menuLink.classList.add('active');
                    }
                });
            });
        });

        // Tab functionality
        const tabLinks = document.querySelectorAll('.tab-link');
        const tabContents = document.querySelectorAll('.tab-content');

        tabLinks.forEach(link => {
            link.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                
                // Remove active class from all tabs and contents
                tabLinks.forEach(link => link.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to current tab and content
                this.classList.add('active');
                document.getElementById(tabId).classList.add('active');
            });
        });

        // Modal functionality
        function setupModal(triggerSelector, modalId) {
            const modal = document.getElementById(modalId);
            const triggers = document.querySelectorAll(triggerSelector);
            const closeButtons = modal.querySelectorAll('.modal-close, .modal-close-btn');
            
            triggers.forEach(trigger => {
                trigger.addEventListener('click', function() {
                    modal.style.display = 'flex';
                    
                    // Set data attributes if needed
                    if (modalId === 'approve-modal') {
                        const applicationId = this.getAttribute('data-application-id');
                        const jobId = this.getAttribute('data-job-id');
                        const fundiName = this.getAttribute('data-fundi-name');
                        
                        document.getElementById('application_id').value = applicationId;
                        document.getElementById('job_id').value = jobId;
                        document.getElementById('fundi-name-placeholder').textContent = fundiName;
                    } else if (modalId === 'complete-modal') {
                        const jobId = this.getAttribute('data-id');
                        document.getElementById('complete_job_id').value = jobId;
                    }
                });
            });
            
            closeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    modal.style.display = 'none';
                });
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        }
        
        // Setup modals
        setupModal('.approve-application', 'approve-modal');
        setupModal('.complete-job', 'complete-modal');
        
        // Handle approve confirmation
        document.getElementById('confirm-approve').addEventListener('click', function() {
            document.getElementById('approve-form').submit();
        });
        
        // Handle complete job confirmation
        document.getElementById('confirm-complete').addEventListener('click', function() {
            document.getElementById('complete-form').submit();
        });
        
        // Rating functionality
        const ratingStars = document.querySelectorAll('.rating-star');
        const ratingInput = document.getElementById('rating_value');
        
        ratingStars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = parseInt(this.getAttribute('data-rating'));
                ratingInput.value = rating;
                
                // Update stars UI
                ratingStars.forEach(s => {
                    const starRating = parseInt(s.getAttribute('data-rating'));
                    if (starRating <= rating) {
                        s.classList.add('active');
                    } else {
                        s.classList.remove('active');
                    }
                });
            });
        });
        
        // View job details (placeholder functionality)
        const viewJobButtons = document.querySelectorAll('.view-job');
        viewJobButtons.forEach(button => {
            button.addEventListener('click', function() {
                const jobId = this.getAttribute('data-id');
                alert('View job details for job ID: ' + jobId + '\nThis functionality would show job details and applications.');
            });
        });
        
        // View fundi profile (placeholder functionality)
        const viewProfileButtons = document.querySelectorAll('.view-fundi-profile');
        viewProfileButtons.forEach(button => {
            button.addEventListener('click', function() {
                const fundiId = this.getAttribute('data-id');
                alert('View fundi profile for fundi ID: ' + fundiId + '\nThis functionality would show the fundi\'s profile, skills, and reviews.');
            });
        });
        
        // Message fundi (placeholder functionality)
        const messageButtons = document.querySelectorAll('.message-fundi');
        messageButtons.forEach(button => {
            button.addEventListener('click', function() {
                const fundiId = this.getAttribute('data-id');
                alert('Message fundi with ID: ' + fundiId + '\nThis functionality would open a messaging interface.');
            });
        });
    });
</script>
</body>
</html>
