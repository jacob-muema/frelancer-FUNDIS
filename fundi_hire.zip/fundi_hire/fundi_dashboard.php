<?php
session_start();

// Check if user is logged in and is a fundi
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'fundi') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "fundihire";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fundi_id = $_SESSION['user_id'];
$fundi_name = isset($_SESSION['name']) ? $_SESSION['name'] : "Fundi";
$profile_message = "";

// Handle job application submission
$application_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_job'])) {
    $job_id = mysqli_real_escape_string($conn, $_POST['job_id']);
    $proposal = mysqli_real_escape_string($conn, $_POST['proposal']);
    $bid_amount = floatval($_POST['bid_amount']);

    // Check if already applied
    $check_query = "SELECT id FROM job_applications WHERE job_id = $job_id AND fundi_id = $fundi_id";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        $application_message = "You have already applied for this job.";
    } else {
        $stmt = $conn->prepare("INSERT INTO job_applications (job_id, fundi_id, proposal, bid_amount) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $job_id, $fundi_id, $proposal, $bid_amount);

        if ($stmt->execute()) {
            $application_message = "Application submitted successfully!";
        } else {
            $application_message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle job progress update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_progress'])) {
    $job_id = intval($_POST['job_id']);
    $progress = intval($_POST['progress']);
    $progress_note = mysqli_real_escape_string($conn, $_POST['progress_note']);
    
    // In a real application, you would save this to a job_progress table
    // For now, we'll just show a success message
    $progress_message = "Progress updated successfully!";
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $bio = mysqli_real_escape_string($conn, $_POST['bio']);

    // Update user profile
    $stmt = $conn->prepare("UPDATE users SET phone = ?, location = ?, bio = ? WHERE id = ?");
    $stmt->bind_param("sssi", $phone, $location, $bio, $fundi_id);

    if ($stmt->execute()) {
        $profile_message = "Profile updated successfully!";
        
        // Update skills if provided
        if (isset($_POST['skills']) && is_array($_POST['skills'])) {
            // First, remove existing skills
            $conn->query("DELETE FROM fundi_skills WHERE fundi_id = $fundi_id");
            
            // Then add new skills
            foreach ($_POST['skills'] as $skill) {
                // Get or create skill ID
                $skill = mysqli_real_escape_string($conn, $skill);
                $skill_query = "SELECT id FROM skills WHERE name = '$skill'";
                $skill_result = $conn->query($skill_query);
                
                if ($skill_result->num_rows > 0) {
                    $skill_id = $skill_result->fetch_assoc()['id'];
                } else {
                    $conn->query("INSERT INTO skills (name) VALUES ('$skill')");
                    $skill_id = $conn->insert_id;
                }
                
                // Add to fundi_skills
                $conn->query("INSERT INTO fundi_skills (fundi_id, skill_id) VALUES ($fundi_id, $skill_id)");
            }
        }
    } else {
        $profile_message = "Error updating profile: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch user profile data
$profile_query = "SELECT * FROM users WHERE id = $fundi_id";
$profile_result = $conn->query($profile_query);
$profile_data = $profile_result->fetch_assoc();

// Fetch user skills
$skills_query = "SELECT s.name FROM fundi_skills fs 
            JOIN skills s ON fs.skill_id = s.id 
            WHERE fs.fundi_id = $fundi_id";
$skills_result = $conn->query($skills_query);
$user_skills = [];
if ($skills_result->num_rows > 0) {
    while ($skill = $skills_result->fetch_assoc()) {
        $user_skills[] = $skill['name'];
    }
}

// Fetch available jobs
$jobs_query = "SELECT j.*, u.name as client_name, u.location as client_location, u.email as client_email
          FROM jobs j 
          JOIN users u ON j.client_id = u.id 
          WHERE j.status = 'open' 
          ORDER BY j.created_at DESC";
$jobs_result = $conn->query($jobs_query);

// Fetch fundi's applications
$applications_query = "SELECT ja.*, j.title, j.description, j.budget, j.location, j.status as job_status, u.name as client_name 
                  FROM job_applications ja 
                  JOIN jobs j ON ja.job_id = j.id 
                  JOIN users u ON j.client_id = u.id 
                  WHERE ja.fundi_id = $fundi_id 
                  ORDER BY ja.created_at DESC";
$applications_result = $conn->query($applications_query);

// Fetch active jobs (accepted applications)
$active_jobs_query = "SELECT j.*, u.name as client_name, u.email as client_email, u.phone as client_phone, ja.id as application_id 
                 FROM jobs j 
                 JOIN job_applications ja ON j.id = ja.job_id 
                 JOIN users u ON j.client_id = u.id 
                 WHERE ja.fundi_id = $fundi_id AND ja.status = 'accepted' AND j.status = 'assigned' 
                 ORDER BY j.updated_at DESC";
$active_jobs_result = $conn->query($active_jobs_query);

// Fetch completed jobs
$completed_jobs_query = "SELECT j.*, u.name as client_name, u.email as client_email, u.phone as client_phone
                    FROM jobs j 
                    JOIN job_applications ja ON j.id = ja.job_id 
                    JOIN users u ON j.client_id = u.id 
                    WHERE ja.fundi_id = $fundi_id AND j.status = 'completed' AND ja.status = 'accepted'
                    ORDER BY j.updated_at DESC";
$completed_jobs_result = $conn->query($completed_jobs_query);

// Count stats
$jobs_count = $jobs_result->num_rows;
$applications_count = $applications_result->num_rows;
$active_jobs_count = $active_jobs_result->num_rows;
$completed_jobs_count = $completed_jobs_result->num_rows;
$unread_messages = 0; // Placeholder for messages count

// Calculate earnings (placeholder)
$earnings_query = "SELECT SUM(ja.bid_amount) as total_earnings 
                  FROM job_applications ja 
                  JOIN jobs j ON ja.job_id = j.id 
                  WHERE ja.fundi_id = $fundi_id AND ja.status = 'accepted' AND (j.status = 'completed' OR j.status = 'assigned')";
$earnings_result = $conn->query($earnings_query);
$total_earnings = $earnings_result->fetch_assoc()['total_earnings'] ?: 0;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fundi Dashboard - FundiHire</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --secondary: #f59e0b;
            --secondary-dark: #d97706;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f1f5f9;
            --gray: #64748b;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --border-radius: 0.5rem;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }

        /* Line clamp utility */
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .line-clamp-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Layout */
        .dashboard {
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            color: var(--white);
            padding: 20px 0;
            position: fixed;
            width: 280px;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: var(--shadow);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo span {
            color: var(--secondary);
        }

        .user-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        .user-avatar {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background-color: var(--secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            font-size: 36px;
            color: var(--white);
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border: 3px solid rgba(255, 255, 255, 0.3);
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-name {
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 5px;
        }

        .user-role {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            background-color: rgba(255, 255, 255, 0.1);
            padding: 3px 10px;
            border-radius: 20px;
        }

        .sidebar-menu {
            padding: 20px;
        }

        .menu-title {
            text-transform: uppercase;
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
            margin: 20px 0 10px;
            letter-spacing: 1px;
        }

        .menu-items {
            list-style: none;
        }

        .menu-item {
            margin-bottom: 8px;
        }

        .menu-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: var(--border-radius);
            transition: var(--transition);
            cursor: pointer;
        }

        .menu-link:hover, .menu-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .menu-link i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .badge {
            background-color: var(--danger);
            color: var(--white);
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 11px;
            margin-left: auto;
            font-weight: 500;
        }

        /* Main Content */
        .main-content {
            grid-column: 2;
            padding: 25px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e2e8f0;
        }

        .page-title {
            font-size: 28px;
            color: var(--dark);
            font-weight: 700;
        }

        .header-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 18px;
            background-color: var(--primary);
            color: var(--white);
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .btn:active {
            transform: translateY(-1px);
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-primary {
            background-color: var(--primary);
        }

        .btn-secondary {
            background-color: var(--secondary);
            color: var(--white);
        }

        .btn-success {
            background-color: var(--success);
        }

        .btn-danger {
            background-color: var(--danger);
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }

        .btn-outline:hover {
            background-color: var(--primary);
            color: var(--white);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 14px;
        }

        /* Dashboard Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: var(--white);
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background-color: var(--primary);
        }

        .stat-card.blue::before {
            background-color: var(--info);
        }

        .stat-card.green::before {
            background-color: var(--success);
        }

        .stat-card.orange::before {
            background-color: var(--warning);
        }

        .stat-card.red::before {
            background-color: var(--danger);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .stat-icon.blue {
            background-color: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .stat-icon.green {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .stat-icon.orange {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .stat-icon.red {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .stat-info {
            flex: 1;
        }

        .stat-value {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            font-weight: 500;
        }

        /* Tabs */
        .tabs {
            margin-bottom: 25px;
        }

        .tab-nav {
            display: flex;
            background-color: var(--white);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .tab-link {
            flex: 1;
            padding: 15px;
            text-align: center;
            background-color: var(--white);
            color: var(--dark);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            border-bottom: 3px solid transparent;
            cursor: pointer;
        }

        .tab-link.active {
            border-bottom-color: var(--primary);
            color: var(--primary);
        }

        .tab-link:hover:not(.active) {
            background-color: var(--light);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Job Cards */
        .jobs-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 25px;
        }

        .job-card {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
            border: 1px solid #e2e8f0;
        }

        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .job-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #f8fafc;
        }

        .job-title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark);
        }

        .job-date {
            color: var(--gray);
            font-size: 13px;
            font-weight: 500;
        }

        .job-body {
            padding: 20px;
        }

        .job-description {
            color: #475569;
            margin-bottom: 20px;
            font-size: 15px;
        }

        .job-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }

        .job-meta-item {
            display: flex;
            align-items: center;
            font-size: 14px;
            color: var(--gray);
            background-color: #f1f5f9;
            padding: 6px 12px;
            border-radius: 20px;
        }

        .job-meta-item i {
            margin-right: 8px;
            font-size: 14px;
        }

        .job-budget {
            font-weight: bold;
            color: var(--success);
        }

        .job-footer {
            padding: 15px 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8fafc;
        }

        .job-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .status-open {
            background-color: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .status-pending {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .status-accepted {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .status-rejected {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        /* Client Info */
        .client-info {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8fafc;
            border-radius: var(--border-radius);
        }

        .client-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: var(--dark);
            margin-right: 15px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .client-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .client-details {
            flex: 1;
        }

        .client-name {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .client-contact {
            font-size: 13px;
            color: var(--gray);
        }

        /* Application Form */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1100;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background-color: var(--white);
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: var(--shadow-lg);
            position: relative;
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background-color: var(--white);
            z-index: 10;
        }

        .modal-title {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 22px;
            cursor: pointer;
            color: var(--gray);
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }

        .modal-close:hover {
            background-color: #f1f5f9;
            color: var(--danger);
        }

        .modal-body {
            padding: 20px;
        }

        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            position: sticky;
            bottom: 0;
            background-color: var(--white);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: var(--border-radius);
            font-size: 15px;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .success-message {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            border-left: 4px solid var(--success);
        }

        .success-message i {
            margin-right: 10px;
            font-size: 18px;
        }

        /* Profile Section */
        .profile-section {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 30px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: var(--light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: var(--dark);
            margin-right: 25px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border: 4px solid #e2e8f0;
        }

        .profile-info h2 {
            font-size: 28px;
            margin-bottom: 8px;
            color: var(--dark);
        }

        .profile-info p {
            color: var(--gray);
            font-size: 16px;
        }

        .profile-form {
            margin-top: 20px;
        }

        /* Skills Section */
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }

        .skill-checkbox {
            display: none;
        }

        .skill-label {
            display: inline-block;
            padding: 8px 15px;
            background-color: var(--light);
            border-radius: 20px;
            font-size: 14px;
            cursor: pointer;
            transition: var(--transition);
        }

        .skill-checkbox:checked + .skill-label {
            background-color: var(--primary);
            color: var(--white);
        }

        /* Progress tracker */
        .progress-tracker {
            margin: 30px 0;
        }

        .progress-steps {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin-bottom: 30px;
        }

        .progress-steps::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: #e2e8f0;
            z-index: 1;
        }

        .progress-step {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
        }

        .step-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            color: var(--gray);
            font-size: 14px;
            font-weight: bold;
            position: relative;
        }

        .step-icon.active {
            background-color: var(--primary);
            color: var(--white);
        }

        .step-icon.completed {
            background-color: var(--success);
            color: var(--white);
        }

        .step-label {
            font-size: 13px;
            color: var(--gray);
            text-align: center;
            font-weight: 500;
        }

        .step-label.active {
            color: var(--primary);
            font-weight: 600;
        }

        .step-label.completed {
            color: var(--success);
            font-weight: 600;
        }

        /* Progress update form */
        .progress-update-form {
            background-color: #f8fafc;
            padding: 20px;
            border-radius: var(--border-radius);
            margin-top: 20px;
            border: 1px solid #e2e8f0;
        }

        .progress-slider {
            width: 100%;
            margin: 10px 0;
        }

        /* Portfolio section */
        .portfolio-section {
            margin-top: 30px;
        }

        .portfolio-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            color: var(--dark);
            display: flex;
            align-items: center;
        }

        .portfolio-title i {
            margin-right: 10px;
            color: var(--primary);
        }

        .portfolio-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .portfolio-item {
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            position: relative;
            height: 150px;
            background-color: #f1f5f9;
        }

        .portfolio-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .portfolio-item:hover img {
            transform: scale(1.05);
        }

        .portfolio-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 0.7);
            color: var(--white);
            padding: 10px;
            font-size: 14px;
            transform: translateY(100%);
            transition: var(--transition);
        }

        .portfolio-item:hover .portfolio-overlay {
            transform: translateY(0);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 30px;
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        .empty-icon {
            font-size: 60px;
            color: #cbd5e1;
            margin-bottom: 25px;
        }

        .empty-title {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .empty-description {
            color: var(--gray);
            margin-bottom: 25px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            font-size: 16px;
            line-height: 1.6;
        }

        /* Section visibility */
        .section {
            display: none;
        }

        .section.active {
            display: block;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .dashboard {
                grid-template-columns: 1fr;
            }

            .sidebar {
                display: none;
                width: 100%;
            }

            .sidebar.active {
                display: block;
            }

            .main-content {
                grid-column: 1;
            }

            .mobile-menu-toggle {
                display: block;
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1200;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background-color: var(--primary);
                color: var(--white);
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                border: none;
                cursor: pointer;
            }
        }

        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }

            .jobs-container {
                grid-template-columns: 1fr;
            }

            .form-row {
                flex-direction: column;
                gap: 0;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .header-actions {
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 576px) {
            .btn {
                padding: 8px 15px;
                font-size: 14px;
            }

            .tab-nav {
                flex-direction: column;
            }

            .profile-header {
                flex-direction: column;
                text-align: center;
            }

            .profile-avatar {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
<div class="dashboard">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo"><span>Fundi</span>Hire</div>
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-name"><?php echo $fundi_name; ?></div>
                <div class="user-role">Professional Fundi</div>
            </div>
        </div>
        <div class="sidebar-menu">
            <div class="menu-title">Main Menu</div>
            <ul class="menu-items">
                <li class="menu-item">
                    <a class="menu-link active" data-section="dashboard-section">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="jobs-section">
                        <i class="fas fa-briefcase"></i> Browse Jobs
                        <?php if ($jobs_count > 0): ?>
                            <span class="badge"><?php echo $jobs_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="applications-section">
                        <i class="fas fa-file-alt"></i> My Applications
                        <?php if ($applications_count > 0): ?>
                            <span class="badge"><?php echo $applications_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="active-jobs-section">
                        <i class="fas fa-tasks"></i> Active Jobs
                        <?php if ($active_jobs_count > 0): ?>
                            <span class="badge"><?php echo $active_jobs_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
            <div class="menu-title">Account</div>
            <ul class="menu-items">
                <li class="menu-item">
                    <a class="menu-link" data-section="profile-section">
                        <i class="fas fa-user-circle"></i> My Profile
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="portfolio-section">
                        <i class="fas fa-images"></i> My Portfolio
                    </a>
                </li>
                <li class="menu-item">
                    <a class="menu-link" data-section="messages-section">
                        <i class="fas fa-envelope"></i> Messages
                        <?php if ($unread_messages > 0): ?>
                            <span class="badge"><?php echo $unread_messages; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="logout.php" class="menu-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Dashboard Section -->
        <section id="dashboard-section" class="section active">
            <div class="page-header">
                <h1 class="page-title">Welcome, <?php echo $fundi_name; ?>!</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="profile-section">
                        <i class="fas fa-user-edit"></i> Update Profile
                    </button>
                    <button class="btn btn-primary" data-section="jobs-section">
                        <i class="fas fa-search"></i> Find Jobs
                    </button>
                </div>
            </div>

            <!-- Stats -->
            <div class="stats-container">
                <div class="stat-card blue">
                    <div class="stat-icon blue">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $jobs_count; ?></div>
                        <div class="stat-label">Available Jobs</div>
                    </div>
                </div>
                <div class="stat-card green">
                    <div class="stat-icon green">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $applications_count; ?></div>
                        <div class="stat-label">My Applications</div>
                    </div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-icon orange">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value"><?php echo $active_jobs_count; ?></div>
                        <div class="stat-label">Active Jobs</div>
                    </div>
                </div>
                <div class="stat-card red">
                    <div class="stat-icon red">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-value">KES <?php echo number_format($total_earnings, 2); ?></div>
                        <div class="stat-label">Total Earnings</div>
                    </div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="tabs">
                <div class="tab-nav">
                    <div class="tab-link active" data-tab="available-jobs">Available Jobs</div>
                    <div class="tab-link" data-tab="my-applications">My Applications</div>
                    <div class="tab-link" data-tab="active-jobs">Active Jobs</div>
                </div>
            </div>

            <!-- Available Jobs Tab -->
            <div id="available-jobs" class="tab-content active">
                <?php if ($jobs_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($jobs_result, 0);
                        while ($job = $jobs_result->fetch_assoc()): 
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                                    <div class="job-date"><?php echo date('M d, Y', strtotime($job['created_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <div class="client-info">
                                        <div class="client-avatar">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="client-details">
                                            <div class="client-name"><?php echo $job['client_name']; ?></div>
                                            <div class="client-contact">
                                                <i class="fas fa-map-marker-alt"></i> <?php echo $job['client_location']; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="job-description line-clamp-3"><?php echo htmlspecialchars($job['description']); ?></p>
                                    <div class="job-meta">
                                        <div class="job-meta-item">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($job['location']); ?>
                                        </div>
                                        <div class="job-meta-item job-budget">
                                            <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($job['budget'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <span class="job-status status-open">Open</span>
                                    <button class="btn btn-primary btn-sm apply-btn" data-job-id="<?php echo $job['id']; ?>" data-job-title="<?php echo htmlspecialchars($job['title']); ?>">Apply Now</button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-briefcase"></i></div>
                        <h3 class="empty-title">No Jobs Available</h3>
                        <p class="empty-description">There are no jobs available at the moment. Check back later or update your skills to match more job opportunities.</p>
                        <button class="btn btn-primary" data-section="profile-section">Update Skills</button>
                    </div>
                <?php endif; ?>
            </div>

            <!-- My Applications Tab -->
            <div id="my-applications" class="tab-content">
                <?php if ($applications_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($applications_result, 0);
                        while ($application = $applications_result->fetch_assoc()): 
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($application['title']); ?></h3>
                                    <div class="job-date">Applied: <?php echo date('M d, Y', strtotime($application['created_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <p class="job-description line-clamp-2"><?php echo htmlspecialchars($application['description']); ?></p>
                                    <div class="job-meta">
                                        <div class="job-meta-item">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($application['location']); ?>
                                        </div>
                                        <div class="job-meta-item">
                                            <i class="fas fa-money-bill-wave"></i> Budget: KES <?php echo number_format($application['budget'], 2); ?>
                                        </div>
                                        <div class="job-meta-item job-budget">
                                            <i class="fas fa-hand-holding-usd"></i> Your Bid: KES <?php echo number_format($application['bid_amount'], 2); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <?php if ($application['status'] == 'pending'): ?>
                                        <span class="job-status status-pending">Pending</span>
                                    <?php elseif ($application['status'] == 'accepted'): ?>
                                        <span class="job-status status-accepted">Accepted</span>
                                    <?php else: ?>
                                        <span class="job-status status-rejected">Rejected</span>
                                    <?php endif; ?>
                                    <button class="btn btn-outline btn-sm view-application" data-id="<?php echo $application['id']; ?>">View Details</button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-file-alt"></i></div>
                        <h3 class="empty-title">No Applications Yet</h3>
                        <p class="empty-description">You haven't applied to any jobs yet. Browse available jobs and start applying!</p>
                        <button class="btn btn-primary tab-link" data-tab="available-jobs">Browse Jobs</button>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Active Jobs Tab -->
            <div id="active-jobs" class="tab-content">
                <?php if ($active_jobs_count > 0): ?>
                    <div class="jobs-container">
                        <?php 
                        // Reset the result pointer
                        mysqli_data_seek($active_jobs_result, 0);
                        while ($active_job = $active_jobs_result->fetch_assoc()): 
                        ?>
                            <div class="job-card">
                                <div class="job-header">
                                    <h3 class="job-title"><?php echo htmlspecialchars($active_job['title']); ?></h3>
                                    <div class="job-date">Started: <?php echo date('M d, Y', strtotime($active_job['updated_at'])); ?></div>
                                </div>
                                <div class="job-body">
                                    <div class="client-info">
                                        <div class="client-avatar">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="client-details">
                                            <div class="client-name"><?php echo $active_job['client_name']; ?></div>
                                            <div class="client-contact">
                                                <i class="fas fa-phone"></i> <?php echo $active_job['client_phone']; ?> | 
                                                <i class="fas fa-envelope"></i> <?php echo $active_job['client_email']; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="job-description line-clamp-2"><?php echo htmlspecialchars($active_job['description']); ?></p>
                                    <div class="job-meta">
                                        <div class="job-meta-item">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($active_job['location']); ?>
                                        </div>
                                        <div class="job-meta-item job-budget">
                                            <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($active_job['budget'], 2); ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Progress tracker -->
                                    <div class="progress-tracker">
                                        <div class="progress-steps">
                                            <div class="progress-step">
                                                <div class="step-icon completed">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                                <div class="step-label completed">Assigned</div>
                                            </div>
                                            <div class="progress-step">
                                                <div class="step-icon active">
                                                    <i class="fas fa-tools"></i>
                                                </div>
                                                <div class="step-label active">In Progress</div>
                                            </div>
                                            <div class="progress-step">
                                                <div class="step-icon">
                                                    <i class="fas fa-check-circle"></i>
                                                </div>
                                                <div class="step-label">Completed</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Progress update form -->
                                    <div class="progress-update-form">
                                        <h4>Update Progress</h4>
                                        <form method="post" class="update-progress-form">
                                            <input type="hidden" name="update_progress" value="1">
                                            <input type="hidden" name="job_id" value="<?php echo $active_job['id']; ?>">
                                            
                                            <div class="form-group">
                                                <label class="form-label">Progress: <span class="progress-value">50</span>%</label>
                                                <input type="range" name="progress" min="0" max="100" value="50" class="progress-slider form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label class="form-label">Progress Note</label>
                                                <textarea name="progress_note" class="form-control" placeholder="Provide an update on the job progress..."></textarea>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary btn-sm">
                                                <i class="fas fa-save"></i> Update Progress
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <div class="job-footer">
                                    <span class="job-status status-accepted">In Progress</span>
                                    <div>
                                        <button class="btn btn-outline btn-sm message-client" data-id="<?php echo $active_job['client_id']; ?>">
                                            <i class="fas fa-comment"></i> Message Client
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-tasks"></i></div>
                        <h3 class="empty-title">No Active Jobs</h3>
                        <p class="empty-description">You don't have any active jobs at the moment. Keep applying to find new opportunities!</p>
                        <button class="btn btn-primary tab-link" data-tab="available-jobs">Browse Jobs</button>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- Jobs Section -->
        <section id="jobs-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Available Jobs</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <?php if ($jobs_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($jobs_result, 0);
                    while ($job = $jobs_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                                <div class="job-date"><?php echo date('M d, Y', strtotime($job['created_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <div class="client-info">
                                    <div class="client-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="client-details">
                                        <div class="client-name"><?php echo $job['client_name']; ?></div>
                                        <div class="client-contact">
                                            <i class="fas fa-map-marker-alt"></i> <?php echo $job['client_location']; ?>
                                        </div>
                                    </div>
                                </div>
                                <p class="job-description"><?php echo htmlspecialchars($job['description']); ?></p>
                                <div class="job-meta">
                                    <div class="job-meta-item">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($job['location']); ?>
                                    </div>
                                    <div class="job-meta-item job-budget">
                                        <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($job['budget'], 2); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="job-footer">
                                <span class="job-status status-open">Open</span>
                                <button class="btn btn-primary apply-btn" data-job-id="<?php echo $job['id']; ?>" data-job-title="<?php echo htmlspecialchars($job['title']); ?>">Apply Now</button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-briefcase"></i></div>
                    <h3 class="empty-title">No Jobs Available</h3>
                    <p class="empty-description">There are no jobs available at the moment. Check back later.</p>
                </div>
            <?php endif; ?>
        </section>

        <!-- Applications Section -->
        <section id="applications-section" class="section">
            <div class="page-header">
                <h1 class="page-title">My Applications</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <?php if ($applications_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($applications_result, 0);
                    while ($application = $applications_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($application['title']); ?></h3>
                                <div class="job-date">Applied: <?php echo date('M d, Y', strtotime($application['created_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <p class="job-description line-clamp-2"><?php echo htmlspecialchars($application['description']); ?></p>
                                <div class="application-proposal">
                                    <h4>Your Proposal:</h4>
                                    <p><?php echo nl2br(htmlspecialchars($application['proposal'])); ?></p>
                                </div>
                                <div class="job-meta">
                                    <div class="job-meta-item">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($application['location']); ?>
                                    </div>
                                    <div class="job-meta-item">
                                        <i class="fas fa-money-bill-wave"></i> Budget: KES <?php echo number_format($application['budget'], 2); ?>
                                    </div>
                                    <div class="job-meta-item job-budget">
                                        <i class="fas fa-hand-holding-usd"></i> Your Bid: KES <?php echo number_format($application['bid_amount'], 2); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="job-footer">
                                <?php if ($application['status'] == 'pending'): ?>
                                    <span class="job-status status-pending">Pending</span>
                                <?php elseif ($application['status'] == 'accepted'): ?>
                                    <span class="job-status status-accepted">Accepted</span>
                                <?php else: ?>
                                    <span class="job-status status-rejected">Rejected</span>
                                <?php endif; ?>
                                <button class="btn btn-outline btn-sm view-application" data-id="<?php echo $application['id']; ?>">View Details</button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-file-alt"></i></div>
                    <h3 class="empty-title">No Applications Yet</h3>
                    <p class="empty-description">You haven't applied to any jobs yet. Browse available jobs and start applying!</p>
                    <button class="btn btn-primary" data-section="jobs-section">Browse Jobs</button>
                </div>
            <?php endif; ?>
        </section>

        <!-- Active Jobs Section -->
        <section id="active-jobs-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Active Jobs</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <?php if ($active_jobs_count > 0): ?>
                <div class="jobs-container">
                    <?php 
                    // Reset the result pointer
                    mysqli_data_seek($active_jobs_result, 0);
                    while ($active_job = $active_jobs_result->fetch_assoc()): 
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <h3 class="job-title"><?php echo htmlspecialchars($active_job['title']); ?></h3>
                                <div class="job-date">Started: <?php echo date('M d, Y', strtotime($active_job['updated_at'])); ?></div>
                            </div>
                            <div class="job-body">
                                <div class="client-info">
                                    <div class="client-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="client-details">
                                        <div class="client-name"><?php echo $active_job['client_name']; ?></div>
                                        <div class="client-contact">
                                            <i class="fas fa-phone"></i> <?php echo $active_job['client_phone']; ?> | 
                                            <i class="fas fa-envelope"></i> <?php echo $active_job['client_email']; ?>
                                        </div>
                                    </div>
                                </div>
                                <p class="job-description"><?php echo htmlspecialchars($active_job['description']); ?></p>
                                <div class="job-meta">
                                    <div class="job-meta-item">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($active_job['location']); ?>
                                    </div>
                                    <div class="job-meta-item job-budget">
                                        <i class="fas fa-money-bill-wave"></i> KES <?php echo number_format($active_job['budget'], 2); ?>
                                    </div>
                                </div>
                                
                                <!-- Progress tracker -->
                                <div class="progress-tracker">
                                    <div class="progress-steps">
                                        <div class="progress-step">
                                            <div class="step-icon completed">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="step-label completed">Assigned</div>
                                        </div>
                                        <div class="progress-step">
                                            <div class="step-icon active">
                                                <i class="fas fa-tools"></i>
                                            </div>
                                            <div class="step-label active">In Progress</div>
                                        </div>
                                        <div class="progress-step">
                                            <div class="step-icon">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <div class="step-label">Completed</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Progress update form -->
                                <div class="progress-update-form">
                                    <h4>Update Progress</h4>
                                    <form method="post" class="update-progress-form">
                                        <input type="hidden" name="update_progress" value="1">
                                        <input type="hidden" name="job_id" value="<?php echo $active_job['id']; ?>">
                                        
                                        <div class="form-group">
                                            <label class="form-label">Progress: <span class="progress-value">50</span>%</label>
                                            <input type="range" name="progress" min="0" max="100" value="50" class="progress-slider form-control">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">Progress Note</label>
                                            <textarea name="progress_note" class="form-control" placeholder="Provide an update on the job progress..."></textarea>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fas fa-save"></i> Update Progress
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="job-footer">
                                <span class="job-status status-accepted">In Progress</span>
                                <div>
                                    <button class="btn btn-outline btn-sm message-client" data-id="<?php echo $active_job['client_id']; ?>">
                                        <i class="fas fa-comment"></i> Message Client
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-tasks"></i></div>
                    <h3 class="empty-title">No Active Jobs</h3>
                    <p class="empty-description">You don't have any active jobs at the moment. Keep applying to find new opportunities!</p>
                    <button class="btn btn-primary" data-section="jobs-section">Browse Jobs</button>
                </div>
            <?php endif; ?>
        </section>

        <!-- Profile Section -->
        <section id="profile-section" class="section">
            <div class="page-header">
                <h1 class="page-title">My Profile</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <div class="profile-section">
                <?php if (!empty($profile_message)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $profile_message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="profile-info">
                        <h2><?php echo $fundi_name; ?></h2>
                        <p><i class="fas fa-user-tag"></i> Professional Fundi</p>
                        <?php if (!empty($profile_data['email'])): ?>
                            <p><i class="fas fa-envelope"></i> <?php echo $profile_data['email']; ?></p>
                        <?php endif; ?>
                        <?php if (!empty($profile_data['phone'])): ?>
                            <p><i class="fas fa-phone"></i> <?php echo $profile_data['phone']; ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="profile-form">
                    <form action="" method="post">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" value="<?php echo $fundi_name; ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?php echo isset($profile_data['email']) ? $profile_data['email'] : ''; ?>" disable
>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="phone" class="form-control" placeholder="Enter your phone number" value="<?php echo isset($profile_data['phone']) ? $profile_data['phone'] : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Location</label>
                            <input type="text" name="location" class="form-control" placeholder="Enter your location" value="<?php echo isset($profile_data['location']) ? $profile_data['location'] : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Bio</label>
                            <textarea name="bio" class="form-control" placeholder="Tell clients about yourself and your skills..."><?php echo isset($profile_data['bio']) ? $profile_data['bio'] : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Skills</label>
                            <div class="skills-container">
                                <?php
                                $all_skills = ['Carpentry', 'Plumbing', 'Electrical', 'Painting', 'Masonry', 'Landscaping', 'Cleaning', 'Transport', 'Welding', 'Tiling', 'Roofing', 'Flooring'];
                                foreach ($all_skills as $skill):
                                    $checked = in_array($skill, $user_skills) ? 'checked' : '';
                                ?>
                                <div>
                                    <input type="checkbox" id="skill-<?php echo strtolower($skill); ?>" name="skills[]" value="<?php echo $skill; ?>" class="skill-checkbox" <?php echo $checked; ?>>
                                    <label for="skill-<?php echo strtolower($skill); ?>" class="skill-label"><?php echo $skill; ?></label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Profile
                        </button>
                    </form>
                </div>
            </div>
        </section>

        <!-- Portfolio Section -->
        <section id="portfolio-section" class="section">
            <div class="page-header">
                <h1 class="page-title">My Portfolio</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                    <button class="btn btn-primary" id="add-portfolio">
                        <i class="fas fa-plus"></i> Add Work
                    </button>
                </div>
            </div>

            <div class="profile-section">
                <h2 class="portfolio-title"><i class="fas fa-images"></i> My Work Showcase</h2>
                <p>Showcase your best work to attract more clients. Add photos of your completed projects.</p>
                
                <div class="portfolio-grid">
                    <div class="portfolio-item">
                        <img src="https://images.unsplash.com/photo-1581141849291-1125c7b692b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2FycGVudHJ5fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Carpentry Work">
                        <div class="portfolio-overlay">Kitchen Cabinet Installation</div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://images.unsplash.com/photo-1621689564124-596c0b3bcbd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHBsdW1iaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Plumbing Work">
                        <div class="portfolio-overlay">Bathroom Renovation</div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZWxlY3RyaWNhbHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60" alt="Electrical Work">
                        <div class="portfolio-overlay">Home Rewiring Project</div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cGFpbnRpbmclMjB3YWxsfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Painting Work">
                        <div class="portfolio-overlay">Interior Painting</div>
                    </div>
                </div>
                
                <div class="empty-state" style="display: none;">
                    <div class="empty-icon"><i class="fas fa-images"></i></div>
                    <h3 class="empty-title">No Portfolio Items Yet</h3>
                    <p class="empty-description">You haven't added any work to your portfolio yet. Showcase your skills by adding photos of your completed projects.</p>
                    <button class="btn btn-primary" id="add-portfolio-empty">Add Your First Work</button>
                </div>
            </div>
        </section>

        <!-- Messages Section -->
        <section id="messages-section" class="section">
            <div class="page-header">
                <h1 class="page-title">Messages</h1>
                <div class="header-actions">
                    <button class="btn btn-outline" data-section="dashboard-section">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </button>
                </div>
            </div>

            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-envelope"></i></div>
                <h3 class="empty-title">No Messages Yet</h3>
                <p class="empty-description">You don't have any messages yet. Once you start communicating with clients, your messages will appear here.</p>
                <button class="btn btn-primary" data-section="active-jobs-section">View Active Jobs</button>
            </div>
        </section>
    </main>
</div>

<!-- Application Modal -->
<div id="application-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Apply for <span id="job-title-placeholder"></span></h3>
            <button class="modal-close">&times;</button>
        </div>
        <form id="application-form" method="post">
            <input type="hidden" name="apply_job" value="1">
            <input type="hidden" name="job_id" id="job_id">
            <div class="modal-body">
                <?php if (!empty($application_message)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $application_message; ?>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="proposal" class="form-label">Your Proposal</label>
                    <textarea name="proposal" id="proposal" class="form-control" required placeholder="Describe why you're the best fit for this job. Highlight your relevant skills and experience..."></textarea>
                </div>
                <div class="form-group">
                    <label for="bid_amount" class="form-label">Your Bid (KES)</label>
                    <input type="number" name="bid_amount" id="bid_amount" class="form-control" required placeholder="Enter your bid amount">
                    <small>Provide a competitive bid that reflects the quality of your work.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline modal-close-btn">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit Application</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Section navigation
        const menuLinks = document.querySelectorAll('.menu-link[data-section], .btn[data-section]');
        const sections = document.querySelectorAll('.section');

        menuLinks.forEach(link => {
            link.addEventListener('click', function() {
                const sectionId = this.getAttribute('data-section');
                
                // Hide all sections
                sections.forEach(section => {
                    section.classList.remove('active');
                });
                
                // Show selected section
                document.getElementById(sectionId).classList.add('active');
                
                // Update active menu link
                document.querySelectorAll('.menu-link').forEach(menuLink => {
                    menuLink.classList.remove('active');
                    if (menuLink.getAttribute('data-section') === sectionId) {
                        menuLink.classList.add('active');
                    }
                });
            });
        });

        // Tab functionality
        const tabLinks = document.querySelectorAll('.tab-link');
        const tabContents = document.querySelectorAll('.tab-content');

        tabLinks.forEach(link => {
            link.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                
                // Remove active class from all tabs and contents
                tabLinks.forEach(link => link.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to current tab and content
                this.classList.add('active');
                document.getElementById(tabId).classList.add('active');
            });
        });

        // Modal functionality
        const modal = document.getElementById('application-modal');
        const applyButtons = document.querySelectorAll('.apply-btn');
        const closeButtons = document.querySelectorAll('.modal-close, .modal-close-btn');
        const jobIdInput = document.getElementById('job_id');
        const jobTitlePlaceholder = document.getElementById('job-title-placeholder');

        applyButtons.forEach(button => {
            button.addEventListener('click', function() {
                const jobId = this.getAttribute('data-job-id');
                const jobTitle = this.getAttribute('data-job-title');
                jobIdInput.value = jobId;
                jobTitlePlaceholder.textContent = jobTitle;
                modal.classList.add('active');
            });
        });

        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                modal.classList.remove('active');
            });
        });

        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
        
        // Progress slider functionality
        const progressSliders = document.querySelectorAll('.progress-slider');
        progressSliders.forEach(slider => {
            const valueDisplay = slider.parentElement.querySelector('.progress-value');
            slider.addEventListener('input', function() {
                valueDisplay.textContent = this.value;
            });
        });
        
        // View application details (placeholder functionality)
        const viewApplicationButtons = document.querySelectorAll('.view-application');
        viewApplicationButtons.forEach(button => {
            button.addEventListener('click', function() {
                const applicationId = this.getAttribute('data-id');
                alert('View application details for application ID: ' + applicationId + '\nThis functionality would show the full application details.');
            });
        });
        
        // Message client (placeholder functionality)
        const messageButtons = document.querySelectorAll('.message-client');
        messageButtons.forEach(button => {
            button.addEventListener('click', function() {
                const clientId = this.getAttribute('data-id');
                alert('Message client with ID: ' + clientId + '\nThis functionality would open a messaging interface.');
            });
        });
        
        // Add portfolio item (placeholder functionality)
        const addPortfolioButtons = document.querySelectorAll('#add-portfolio, #add-portfolio-empty');
        addPortfolioButtons.forEach(button => {
            button.addEventListener('click', function() {
                alert('Add portfolio item\nThis functionality would allow you to upload photos of your work.');
            });
        });
    });
</script>
</body>
</html>

